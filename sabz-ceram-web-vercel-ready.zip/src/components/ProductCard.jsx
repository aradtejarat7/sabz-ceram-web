import React from 'react';

export default function ProductCard({ title, image, description, instagram }) {
  return (
    <div className="border rounded-lg shadow hover:shadow-lg transition overflow-hidden">
      <img src={image} alt={title} className="w-full h-60 object-cover" />
      <div className="p-4">
        <h2 className="text-lg font-bold mb-2">{title}</h2>
        <p className="text-sm text-gray-600 mb-4">{description}</p>
        {instagram && (
          <a href={instagram} target="_blank" rel="noopener noreferrer" className="text-blue-600 text-sm hover:underline">
            مشاهده در اینستاگرام
          </a>
        )}
      </div>
    </div>
  );
}