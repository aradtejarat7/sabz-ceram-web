import React, { useEffect, useState } from 'react';
import ProductCard from '../components/ProductCard';

const SHEET_API = 'https://api.sheetbest.com/sheets/10859d0c-d8a6-4425-a84c-8bef172f582f';

export default function Home() {
  const [products, setProducts] = useState([]);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    fetch(SHEET_API)
      .then(res => res.json())
      .then(data => setProducts(data));
  }, []);

  const categories = ['All', ...new Set(products.map(p => p.category))];

  const filteredProducts = filter === 'All'
    ? products
    : products.filter(p => p.category === filter);

  return (
    <div className="p-4 max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-6">محصولات سبز سرام</h1>
      <div className="flex flex-wrap justify-center gap-2 mb-6">
        {categories.map(cat => (
          <button key={cat} onClick={() => setFilter(cat)} className={`px-4 py-1 rounded-full text-sm border ${filter === cat ? 'bg-green-700 text-white' : 'bg-white text-green-700'}`}>
            {cat}
          </button>
        ))}
      </div>
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
        {filteredProducts.map((product, idx) => (
          <ProductCard key={idx} {...product} />
        ))}
      </div>
    </div>
  );
}